<?php

namespace App\Constant;

class ConstantSystem
{
    public const AdminRoot =  2;
    public const AdminUser =  1;
    public const User =  0;
    public const KanbanStatus =  1;
}
